<?php
include("conexion.php"); // Llama a tu conexion.php

// Captura los datos del formulario
$nombre = $_POST['nombre'] ?? '';
$correo = $_POST['correo'] ?? '';
$contrasena = $_POST['password'] ?? '';

// Validar que no estén vacíos
if(empty($nombre) || empty($correo) || empty($contrasena)){
    die("❌ Todos los campos son obligatorios");
}

// Preparar la consulta segura
$stmt = $conexion->prepare("INSERT INTO usuarios (nombre, correo, contrasena) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nombre, $correo, $contrasena);

// Ejecutar y mostrar resultado
if($stmt->execute()){
    echo "✅ Registro exitoso";
} else {
    echo "❌ Error al registrar: " . $conexion->error;
}

$stmt->close();
$conexion->close();
?>