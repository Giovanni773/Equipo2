<?php
include("conexion.php");

$id = $_POST['id'] ?? '';

if(empty($id)){
    die("❌ Se requiere el ID de la tarea");
}

$stmt = $conexion->prepare("DELETE FROM tareas WHERE id=?");
$stmt->bind_param("i", $id);

if($stmt->execute()){
    echo "✅ Tarea borrada correctamente";
} else {
    echo "❌ Error al borrar tarea: ".$conexion->error;
}

$stmt->close();
$conexion->close();
?>