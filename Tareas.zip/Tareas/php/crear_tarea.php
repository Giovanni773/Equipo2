<?php
include("conexion.php");

$nombre_usuario = $_POST['nombre_usuario'] ?? '';
$tarea = $_POST['tarea'] ?? '';

if(empty($nombre_usuario) || empty($tarea)){
    die("❌ Todos los campos son obligatorios");
}

$stmt = $conexion->prepare("INSERT INTO tareas (nombre_usuario, tarea) VALUES (?, ?)");
$stmt->bind_param("ss", $nombre_usuario, $tarea);

if($stmt->execute()){
    echo "✅ Tarea creada correctamente";
} else {
    echo "❌ Error al crear tarea: ".$conexion->error;
}

$stmt->close();
$conexion->close();
?>