<?php
include("conexion.php");

$id = $_POST['id'] ?? '';
$tarea = $_POST['tarea'] ?? '';

if(empty($id) || empty($tarea)){
    die("❌ Todos los campos son obligatorios");
}

$stmt = $conexion->prepare("UPDATE tareas SET tarea=? WHERE id=?");
$stmt->bind_param("si", $tarea, $id);

if($stmt->execute()){
    echo "✅ Tarea editada correctamente";
} else {
    echo "❌ Error al editar tarea: ".$conexion->error;
}

$stmt->close();
$conexion->close();
?>