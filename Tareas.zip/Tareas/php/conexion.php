<?php
$servidor = "localhost";
$usuario = "root"; // tu usuario de XAMPP
$clave = "";       // por defecto está vacío
$bd = "asignacion_tareas"; // nombre de tu base de datos

$conexion = new mysqli($servidor, $usuario, $clave, $bd);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
?>